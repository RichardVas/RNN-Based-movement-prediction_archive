from testcases import *

inp = test8[:-1]
val = test8[1:]

print(inp)
print(val)